StudyBuddy AI Interactive Prototype

Open prototype.html in Chrome, Edge, Firefox, or Safari. Keep the assets folder beside it.

Start testing on Home. Refresh to reset the prototype.

WORKING INTERACTIONS:
- Bottom navigation across all five screens
- Home: add assignment and toggle the three shown assignment checkboxes
- Planner: change day, edit study hours and exam date settings, generate sample schedule, add sample session
- Upload: choose demo notes or local file name, generate simulated summary, go to quiz
- Practice: answer or skip ten sample biology questions
- Feedback: total score and topic bars, missed questions review, restart quiz

LIMITATIONS:
- Not a real AI tool, does not actually use any files uploaded.
- Demo summary and quiz are based on sample Biology content, not actual uploaded documents.
- Only the three most recent assignments are shown on Home.
- Adding manual session on Planner is acknowledged but not permanent on the schedule.
- Some elements in the background are static designs.
